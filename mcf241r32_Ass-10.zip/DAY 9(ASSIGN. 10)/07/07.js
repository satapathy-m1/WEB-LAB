function changeFontSize(size) {
    var paragraph = document.getElementById("textParagraph");
    if (size === 'small') {
        paragraph.style.fontSize = "12px";
    } else if (size === 'medium') {
        paragraph.style.fontSize = "16px";
    } else if (size === 'large') {
        paragraph.style.fontSize = "20px";
    }
}