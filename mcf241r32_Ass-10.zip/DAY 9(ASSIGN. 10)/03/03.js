const str =  document.querySelector('p').textContent;
document.querySelector("button").addEventListener('click', ()=>{
    document.querySelector('p').textContent = " Hello World! ";
    document.querySelector('#b2').style.opacity = "1";
})
document.querySelector('#b2').addEventListener('click', ()=>{
    document.querySelector('p').textContent = str;
    document.querySelector('#b2').style.opacity = "0";
})