function convertTemperature() {
    let temperature = parseFloat(document.getElementById("temperatureInput").value);
    let unit = document.getElementById("unitSelect").value;
    let result;

    if (isNaN(temperature)) {
        result = "Please enter a valid temperature.";
    } else {
        if (unit === "Celsius") {
            result = (temperature * 9/5) + 32 + " °F";
        } else {
            result = (temperature - 32) * 5/9 + " °C";
        }
    }

    document.getElementById("result").innerText = "Converted Temperature: " + result;
}