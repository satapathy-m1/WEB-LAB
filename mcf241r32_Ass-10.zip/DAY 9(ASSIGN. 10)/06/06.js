function displayDateTime(){
    let now = new Date();
    let formattedDateTime = now.toLocaleString();
    document.getElementById("dateTimeDiv").innerText = formattedDateTime;
}