
function redColor(){
    document.body.style.backgroundColor = "red";
}
function greenColor(){
    document.body.style.backgroundColor = "green";
}
function yellowColor(){
    document.body.style.backgroundColor = "yellow";
}
function blackColor(){
    document.body.style.backgroundColor = "black";
}
function defaultColor(){
    document.body.style.backgroundColor = "white";
}