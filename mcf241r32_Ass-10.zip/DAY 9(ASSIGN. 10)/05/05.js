
let hoverDiv = document.getElementById("hoverDiv");
hoverDiv.addEventListener("mouseover", function() {
    alert("Mouse Hovered!");
});