function displayValue() {
    let inputValue = document.getElementById("inputField").value;  
    document.getElementById("displaySpan").innerText = inputValue;
}