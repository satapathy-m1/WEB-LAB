//fibonacci using copy constructor

#include<iostream>
using namespace std;

class Fib{
	int n;
public:
	Fib(){
		int a = 0, b = 1, c;
		cout << "Constructor called";
		cout << "Enter the number " ;
		cin >> n;
		if (n >= 1) cout << a << " ";
		if (n >= 2) cout << b << " ";
		for (int i = 3; i <= n; i++) {
			c = a + b;
			cout << c << " ";
			a = b;
			b = c;
		    }
			cout << a + b;
		    
	}
};

int main()
{
	Fib obj1;
	Fib obj2(obj1);
	cout << "Address of obj1 " << &obj1 << " and" << "Address of obj2 " << &obj2;
	return 0;
}
/*
#include <iostream>
using namespace std;

void fibonacci(int n) {
    int a = 0, b = 1, c;
    
}

int main() {
    int n;
    cout << "Enter the number of terms: ";
    cin >> n;
    fibonacci(n);
    return 0;
}

*/
