//accessing a non-member function
#include<iostream>
using namespace std;

class Hero{

	int health = 90;
	int power = 10;
public:
	int getHealth(){
		return health;
	}
	int getPower(){
		return power;
	}
	void print(){
		cout << "Health is " << getHealth() << " Power is "<< getPower() << endl;
	}
};

void sum(Hero& obj)
{
	obj.print();
	int sum = obj.getHealth() + obj.getPower();
	cout << "Random sum " << sum;
}

int main(){
	Hero obj;
	sum(obj);
	return 0;
}
