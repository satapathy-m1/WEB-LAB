//factorial using constructor

#include<iostream>
using namespace std;

class Fact{

public:
	int n;
	Fact(){
		
		cout << "Enter the number " << endl;
		cin >> n;
		int fact = 1;
		for(int i = n; i >= 1; i--)
		{
			fact *= i;
		}
		cout << "Factorial of " << n << "  is " << fact << endl;
	}
		
};

int main(){
	Fact number1;
	return 0;
}
