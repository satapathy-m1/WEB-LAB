#include<iostream>
using namespace std;

class Matrix{
public:
        static int arr1[3][3];
	static void takeEle()
	{
		for(int i = 0; i < 3; i++)
		{
			for(int j = 0; j < 3; j++)
			{
				arr1[i][j] = i+j;
			}
		}
	}
	static void func(int arr2[][3]){
		for(int i = 0; i < 3; i++)
		{
			for(int j = 0; j < 3; j++)
			{
				cout << arr1[i][j] + arr2[i][j] << " ";
			}
			cout << endl;
		}
		cout << endl;
		cout << "func ends here " << endl;
	}
};
int Matrix :: arr1[3][3];
int main()
{
	int arr2[3][3] = {{4, 3, 2}, {2, 3, 4}, {1, 1, 1}};
	Matrix :: takeEle();
	//Matrix obj1;
	Matrix :: func(arr2);
	return 0;
}
