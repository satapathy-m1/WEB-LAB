//IILUSTRATE CONSTRUCTORS AND DESTRUCTORS

#include<bits/stdc++.h>
using namespace std;

class Mrutyunjaya{
public:
	int height;
	int weight;
	int age;
	char gender;
	
	Mrutyunjaya(int h, int w, int a, char ch)
	{
		this -> height = h;
		this -> weight = w;
		this -> age = a;
		this -> gender = ch;
		cout << "Constructor called as soon as object is created" << endl;
		cout << "height -> " << height << " weight -> " << weight << " age " << age << " gender " << gender << endl;
	}
	
	~Mrutyunjaya()
	{
		cout << "Destructor called as soon as objects life span gets over " << endl;
	}
};

int main()
{	Mrutyunjaya obj1(185, 83, 22, 'M');

	//constructor is called as soon as the object is created
	//Destructor is called to free the used memory used by the obj
	//as soon as its life span gets over
	Mrutyunjaya* obj2 = new Mrutyunjaya(20, 23, 21, 'M');
	return 0;
}
