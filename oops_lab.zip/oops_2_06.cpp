#include <iostream>
using namespace std;

class ObjectCounter {
private:
    static int objectCount;

public:
    	
    ObjectCounter() {
        objectCount++;
    }

    
    ~ObjectCounter() {
        objectCount--;
    }

    
    static int getObjectCount() {
        return objectCount;
    }
};

int ObjectCounter::objectCount = 0;

int main() {
    cout << "Initial object count: " << ObjectCounter::getObjectCount() << endl;

    ObjectCounter obj1;
    ObjectCounter obj2;
    cout << "Object count after creating two objects: " << ObjectCounter::getObjectCount() << endl;

    {
        ObjectCounter obj3;  
        cout << "Object count after creating third object: " << ObjectCounter::getObjectCount() << endl;
    } // obj3 is destroyed after this blockk

    cout << "Object count after obj3 is destroyed: " << ObjectCounter::getObjectCount() << endl;

    return 0;
}
