//name address age salary nand implement getter and setter

#include<iostream>
using namespace std;

class Emp{
	string name;
	string address;
	int age;
	float salary;
public:
	void setValues(string n, string ad, int a, float sal)
	{
		this -> name = n;
		this -> address = ad;
		this -> age = a;
		this -> salary = sal;
	}
	
	string getName(){
		return name;
	}
	string getAddress(){
		return address;
	}
	int getAge(){
		return age;
	}
	int getSalary(){
		return salary;
	}
	~Emp(){
		cout << "Destructor called " << endl;
	}
};

int main()
{
	Emp em1;
	em1.setValues("Prabir", "Odisha", 22, 300000.00);
	cout << "The name of the emplooyee is " << em1.getName()<< endl;
	cout << "The address of the emplo0yee is " << em1.getAddress()<< endl;
	cout << "The Age of the emplo0yee is " << em1.getAge()<< endl;
	cout << "The salary of the emplo0yee is " << em1.getSalary()<< endl;
	return 0;
}
