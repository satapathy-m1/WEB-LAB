//Bank Account Details
#include<iostream>
#include<string>
using namespace std;

class BankAccount{
	string name;
	int acNo;
	string acType;
	float balance;
public:
        BankAccount()
	{
		cout <<"Account creation form" << endl;
		cout << "Enter the username: ";
		cin >> name;
		cout<< endl << "Enter the account type: ";
		cin >> acType;
		cout<<endl << " Enter the account Number: " ;
		cin >> acNo;
		cout<<endl <<"  first deposit is of : ";
		cin >> balance;
		cout << "New Account has been created!!!"<<endl;
		cout << "Account Holder : " << this -> name << endl;
		cout << "Account tyoe: " << this -> acType << endl;
		cout << "Account Number: " << this -> acNo << endl;
		cout << "Balance initially is : " << this -> balance << endl;
	}
	
	void deposit(){
		float money;
		cout <<"Enter the amount: " ;
		cin >> money;
		cout << "deposit  of money " << money << " has been made" << endl;
		
		balance += money;
		cout << endl << "The new balance is " << balance;
	}
	
	void withdrawl(){
		float money;
		cout <<"Enter the withdrawl amount: " ;
		cin >> money;
		cout << "Withdrawl of money " << money << " has been made" << endl;
		balance -= money;
		if(balance < 0 )
			
		{
			balance += money;
			cout << "Invalid withdrawl money " << endl;
		}
		cout << endl << "The remaining balance is " << balance;
	}
	
	void display()
	{
		cout << "Username: " << this -> name;
		cout << endl;
		cout << "Account type: " << this -> acType;
		cout << endl;
		cout << "Account Number: " << this -> acNo;
		cout << endl;
		cout << "Balance in the account: " << this -> balance;
		cout << endl;
	}
};

int main(){
	int case1;
	BankAccount consumer1;
	cout << endl;
	
	do
	{
		cin >> case1;
		switch(case1)
		{
		case 1:
			consumer1.deposit();
			break;
		case 2:
			consumer1.withdrawl();
			break;
		case 3:
			consumer1.display();
			break;
		case 4:
			cout <<"Logged out";
			return 0;
			
		}
	}while(case1 != 4);
/*consumer1.deposit();
//	consumer1.display();
	consumer1.withdrawl();
//	consumer1.display();
//	consumer1.withdrawl();
	consumer1.deposit();
	consumer1.withdrawl();
	consumer1.display();
	*/
	return 0;
}
